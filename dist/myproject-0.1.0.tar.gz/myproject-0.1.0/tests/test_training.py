def test_dummy_training():
    assert 1 + 1 == 2
