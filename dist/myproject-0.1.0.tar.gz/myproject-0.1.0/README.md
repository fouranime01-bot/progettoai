Questo repository contiene:
- Un package Python installabile
- Script di training e predizione
- Test unitari
- Struttura compatibile con Docker e CI/CD
